//! A playback deck: fractional playhead, tempo (pitch) control, cue points, loops.

#[derive(Clone, Debug)]
pub struct Track {
    pub sample_rate: u32,
    pub left: Vec<f32>,
    pub right: Vec<f32>,
}

impl Track {
    pub fn frames(&self) -> usize {
        self.left.len().min(self.right.len())
    }
    pub fn mono(&self) -> Vec<f32> {
        self.left.iter().zip(&self.right).map(|(l, r)| 0.5 * (l + r)).collect()
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Loop {
    pub start: f64,
    pub end: f64,
}

pub struct Deck {
    track: Option<Track>,
    output_rate: u32,
    /// Playhead in track frames (fractional).
    pos: f64,
    /// Playback ratio; 1.0 = original speed. Changes pitch and speed together (vinyl style).
    tempo: f64,
    playing: bool,
    cues: [Option<f64>; 8],
    active_loop: Option<Loop>,
}

#[inline]
fn hermite(y0: f32, y1: f32, y2: f32, y3: f32, t: f32) -> f32 {
    let c0 = y1;
    let c1 = 0.5 * (y2 - y0);
    let c2 = y0 - 2.5 * y1 + 2.0 * y2 - 0.5 * y3;
    let c3 = 0.5 * (y3 - y0) + 1.5 * (y1 - y2);
    ((c3 * t + c2) * t + c1) * t + c0
}

fn sample_at(buf: &[f32], pos: f64) -> f32 {
    if buf.is_empty() || pos < 0.0 {
        return 0.0;
    }
    let i = pos.floor() as isize;
    let t = (pos - pos.floor()) as f32;
    let g = |k: isize| -> f32 {
        let idx = (i + k).clamp(0, buf.len() as isize - 1) as usize;
        buf[idx]
    };
    hermite(g(-1), g(0), g(1), g(2), t)
}

impl Deck {
    pub fn new(output_rate: u32) -> Self {
        Self { track: None, output_rate, pos: 0.0, tempo: 1.0, playing: false, cues: [None; 8], active_loop: None }
    }
    pub fn load(&mut self, track: Track) {
        self.track = Some(track);
        self.pos = 0.0;
        self.playing = false;
        self.cues = [None; 8];
        self.active_loop = None;
    }
    pub fn play(&mut self) { if self.track.is_some() { self.playing = true; } }
    pub fn pause(&mut self) { self.playing = false; }
    pub fn is_playing(&self) -> bool { self.playing }
    pub fn position_frames(&self) -> f64 { self.pos }
    pub fn seek_frames(&mut self, f: f64) { self.pos = f.max(0.0); }
    pub fn set_tempo(&mut self, ratio: f64) { self.tempo = ratio.clamp(0.5, 2.0); }
    pub fn tempo(&self) -> f64 { self.tempo }
    pub fn track(&self) -> Option<&Track> { self.track.as_ref() }

    pub fn set_cue(&mut self, slot: usize) {
        if slot < 8 { self.cues[slot] = Some(self.pos); }
    }
    pub fn jump_cue(&mut self, slot: usize) {
        if let Some(Some(p)) = self.cues.get(slot).copied() { self.pos = p; }
    }
    pub fn cue(&self, slot: usize) -> Option<f64> { self.cues.get(slot).copied().flatten() }

    /// Start a loop of `beats` beats at the current position given the track's BPM.
    pub fn loop_beats(&mut self, bpm: f64, beats: f64) {
        if let Some(t) = &self.track {
            let len = 60.0 / bpm * beats * t.sample_rate as f64;
            self.active_loop = Some(Loop { start: self.pos, end: self.pos + len });
        }
    }
    pub fn exit_loop(&mut self) { self.active_loop = None; }
    pub fn active_loop(&self) -> Option<Loop> { self.active_loop }

    /// Render `out_l.len()` frames. Silence when paused / unloaded / finished.
    pub fn render(&mut self, out_l: &mut [f32], out_r: &mut [f32]) {
        let n = out_l.len().min(out_r.len());
        let Some(track) = &self.track else {
            out_l[..n].fill(0.0);
            out_r[..n].fill(0.0);
            return;
        };
        let step = self.tempo * track.sample_rate as f64 / self.output_rate as f64;
        let total = track.frames() as f64;
        for i in 0..n {
            if !self.playing {
                out_l[i] = 0.0;
                out_r[i] = 0.0;
                continue;
            }
            if let Some(lp) = self.active_loop {
                if self.pos >= lp.end { self.pos = lp.start + (self.pos - lp.end); }
            }
            if self.pos >= total {
                self.playing = false;
                out_l[i] = 0.0;
                out_r[i] = 0.0;
                continue;
            }
            out_l[i] = sample_at(&track.left, self.pos);
            out_r[i] = sample_at(&track.right, self.pos);
            self.pos += step;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ramp(n: usize) -> Track {
        let v: Vec<f32> = (0..n).map(|i| i as f32).collect();
        Track { sample_rate: 1000, left: v.clone(), right: v }
    }

    #[test]
    fn plays_at_unity() {
        let mut d = Deck::new(1000);
        d.load(ramp(100));
        d.play();
        let (mut l, mut r) = (vec![0.0; 10], vec![0.0; 10]);
        d.render(&mut l, &mut r);
        for i in 0..10 { assert!((l[i] - i as f32).abs() < 1e-4); }
    }

    #[test]
    fn half_tempo_interpolates() {
        let mut d = Deck::new(1000);
        d.load(ramp(100));
        d.set_tempo(0.5);
        d.seek_frames(10.0); // away from the clamped track edge
        d.play();
        let (mut l, mut r) = (vec![0.0; 4], vec![0.0; 4]);
        d.render(&mut l, &mut r);
        let expect = [10.0, 10.5, 11.0, 11.5];
        for i in 0..4 { assert!((l[i] - expect[i]).abs() < 1e-3, "{} vs {}", l[i], expect[i]); }
    }

    #[test]
    fn loop_wraps_and_stops_at_end() {
        let mut d = Deck::new(1000);
        d.load(ramp(100));
        d.seek_frames(10.0);
        d.loop_beats(60.0, 0.01); // 10 ms @ 1000 Hz = 10 frames
        d.play();
        let (mut l, mut r) = (vec![0.0; 25], vec![0.0; 25]);
        d.render(&mut l, &mut r);
        assert!(l.iter().all(|&x| (10.0..20.5).contains(&x)));
        d.exit_loop();
        d.seek_frames(95.0);
        let (mut l, mut r) = (vec![0.0; 10], vec![0.0; 10]);
        d.render(&mut l, &mut r);
        assert!(!d.is_playing());
        assert_eq!(l[9], 0.0);
    }

    #[test]
    fn cues_roundtrip() {
        let mut d = Deck::new(1000);
        d.load(ramp(100));
        d.seek_frames(42.0);
        d.set_cue(2);
        d.seek_frames(0.0);
        d.jump_cue(2);
        assert_eq!(d.position_frames(), 42.0);
    }
}
