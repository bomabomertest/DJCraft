//! Two-channel mixer with crossfader curves.
use crate::eq::Eq3;

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Curve {
    /// Smooth blend, constant perceived loudness.
    ConstantPower,
    /// Plain linear blend.
    Linear,
    /// "Scratch" curve: each side is full volume until the fader is nearly at the opposite end.
    Cut,
}

/// `pos` in [-1, 1]; -1 = deck A only, +1 = deck B only. Returns (gain_a, gain_b).
pub fn crossfade(pos: f32, curve: Curve) -> (f32, f32) {
    let x = (pos.clamp(-1.0, 1.0) + 1.0) * 0.5; // 0..1
    match curve {
        Curve::Linear => (1.0 - x, x),
        Curve::ConstantPower => {
            let a = x * std::f32::consts::FRAC_PI_2;
            (a.cos(), a.sin())
        }
        Curve::Cut => {
            const EDGE: f32 = 0.05;
            let ga = if x < 1.0 - EDGE { 1.0 } else { (1.0 - x) / EDGE };
            let gb = if x > EDGE { 1.0 } else { x / EDGE };
            (ga, gb)
        }
    }
}

pub struct Channel {
    pub gain: f32,
    pub eq: Eq3,
}

pub struct Mixer {
    pub a: Channel,
    pub b: Channel,
    pub crossfader: f32,
    pub curve: Curve,
    pub master: f32,
}

impl Mixer {
    pub fn new(sample_rate: u32) -> Self {
        Self {
            a: Channel { gain: 1.0, eq: Eq3::new(sample_rate) },
            b: Channel { gain: 1.0, eq: Eq3::new(sample_rate) },
            crossfader: 0.0,
            curve: Curve::ConstantPower,
            master: 1.0,
        }
    }

    /// Mix two deck buffers into `out`.
    pub fn mix(&mut self, a: (&mut [f32], &mut [f32]), b: (&mut [f32], &mut [f32]), out: (&mut [f32], &mut [f32])) {
        self.a.eq.process(a.0, a.1);
        self.b.eq.process(b.0, b.1);
        let (xa, xb) = crossfade(self.crossfader, self.curve);
        let (ga, gb) = (self.a.gain * xa * self.master, self.b.gain * xb * self.master);
        for i in 0..out.0.len() {
            out.0[i] = a.0[i] * ga + b.0[i] * gb;
            out.1[i] = a.1[i] * ga + b.1[i] * gb;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn endpoints() {
        for c in [Curve::Linear, Curve::ConstantPower, Curve::Cut] {
            let (a, b) = crossfade(-1.0, c);
            assert!((a - 1.0).abs() < 1e-6 && b.abs() < 1e-6);
            let (a, b) = crossfade(1.0, c);
            assert!(a.abs() < 1e-6 && (b - 1.0).abs() < 1e-6);
        }
    }

    #[test]
    fn constant_power_midpoint() {
        let (a, b) = crossfade(0.0, Curve::ConstantPower);
        assert!((a * a + b * b - 1.0).abs() < 1e-5);
    }

    #[test]
    fn cut_keeps_both_open_in_middle() {
        assert_eq!(crossfade(0.0, Curve::Cut), (1.0, 1.0));
    }
}
