//! dj-core: dependency-free DJ engine primitives (decks, EQ, mixer, BPM analysis).
//! Written from a behavioural spec (see SPEC.md); no third-party DJ software code was consulted.
pub mod bpm;
pub mod deck;
pub mod eq;
pub mod mixer;
